import csv
import json
import math
from pathlib import Path
import torch
import trace_original as apparatus

from base_model_research.parameterization import build_model, make_optimizer
from base_model_research.training import CosineSchedule, seed_everything
from base_model_research.models import parameter_count

def save_norm(module, args, output, *, name, store):
    x = args[0].detach()
    sq = x.float().square().mean(-1)
    store.append((name, apparatus.rms(x), x.abs().max().item(), torch.isfinite(x).all().item(),
                  torch.isinf(sq).sum().item(), (output.detach().abs().amax(-1)==0).sum().item(),
                  apparatus.rms(output)))

def gate_plus_residual(module, args, output):
    return args[0] + output

def ablate():
    seed_everything(apparatus.settings.seed)
    model = build_model(apparatus.config, apparatus.hp)
    for l in model.layers:
        l.attention_gate.register_forward_hook(gate_plus_residual)
        l.ffn_gate.register_forward_hook(gate_plus_residual)
    with (apparatus.destination/"identity_added.tsv").open("w") as fh:
        apparatus.out = fh
        apparatus.writer = csv.writer(fh, delimiter="\t")
        apparatus.writer.writerow(["run","update","token_offset","layer","module","metric","value"])
        for off in range(0, 4*apparatus.length, apparatus.length):
            loss,norm = apparatus.evaluate(model,"original_plus_identity",0,off)
            print("restored both identity paths, original gates still present:", off,loss,norm,flush=True)

def replay():
    from functools import partial
    seed_everything(apparatus.settings.seed)
    cfg, hp = apparatus.settings, apparatus.hp
    model = build_model(apparatus.config,hp)
    optim = make_optimizer(model, cfg)
    steps = math.ceil(parameter_count(model) * cfg.tokens_per_parameter / apparatus.production_batch)
    sched = CosineSchedule(optim,steps,cfg.warmup_fraction,cfg.min_lr_ratio)
    with (apparatus.destination/"norm_checks.tsv").open("w") as fh:
        writer = csv.writer(fh,delimiter="\t")
        writer.writerow(["update","module","input_rms","input_max_abs","all_inputs_finite","nonfinite_mean_square_tokens","all_zero_output_tokens","output_rms"])
        for step in range(1,13):
            rows,handles = [],[]
            if step in (1,11,12):
                for i,l in enumerate(model.layers,1):
                    for name in ("input_norm","post_attention_norm"):
                        handles.append(getattr(l,name).register_forward_hook(partial(save_norm,name=f"{i}.{name}",store=rows)))
                handles.append(model.final_norm.register_forward_hook(partial(save_norm,name="final_norm",store=rows)))
            sched.apply(step-1)
            optim.zero_grad(set_to_none=True)
            x,y=apparatus.corpus.batch((step-1)*apparatus.production_batch,apparatus.length,apparatus.length)
            loss = model.loss_sum(x,y,cfg.loss_chunk_size) / apparatus.length
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip).item()
            for h in handles: h.remove()
            for r in rows: writer.writerow((step,*r))
            if step in (1,11,12):
                print("replay update",step,"loss",loss.item(),"norm",norm,"first affected norms",[(r[0],r[4],r[5]) for r in rows if r[4]][:8],flush=True)
            optim.step()

ablate()
replay()
