from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import LogLocator, NullLocator
import numpy as np
import pandas as pd

folder = Path(__file__).parent
all_data = pd.concat([pd.read_csv(folder / name, sep="\t") for name in
                     ["trace.tsv", "fixed_inputs.tsv", "identity_added.tsv"]], ignore_index=True)
grads = all_data[all_data.metric.eq("weight_grad_rms") & all_data.layer.gt(0)].groupby(
    ["run", "module", "layer"]).value.median()
fig, axes = plt.subplots(1, 2, figsize=(10.2, 5.1))
fig.subplots_adjust(top=.72, left=.09, right=.98, bottom=.23, wspace=.25)
colors = ["#14638c","#b54b0d","#185e44","#8d4da0"]
families = ["attention.v_proj","ffn.down_proj","attention_gate.current","ffn_gate.current"]
labels = ["Attention value projection","FFN down projection","Attention connection gate W₁","FFN connection gate W₁"]
for ax, original, restored, title in zip(axes,
        ["original_init", "original_after_two"],
        ["original_plus_identity","original_after_two_plus_identity"],
        ["Before the first update","After two optimizer updates"]):
    for family,color,label in zip(families,colors,labels):
        s=grads.loc[original,family]
        ax.plot(s.index,s,color=color,label=label,lw=2)
    s=grads.loc[restored,"attention.v_proj"]
    ax.plot(s.index,s,lw=1.8,ls="--",color="#444444",label="Attention value with direct skips restored")
    ax.set_yscale("log")
    ax.yaxis.set_major_locator(LogLocator(base=10,numticks=7))
    ax.yaxis.set_minor_locator(NullLocator())
    ax.set(xticks=[1,7,14,21,28],xlim=(1,28),xlabel="Decoder layer (1 = input end)")
    ax.set_title(title,fontsize=12,loc="left",pad=9)
    ax.grid(axis="y",color="#dbe1e5",lw=.7)
    ax.spines[["top","right"]].set_visible(False)
    ax.spines[["left","bottom"]].set_color("#82919c")
axes[0].set_ylabel("RMS of weight gradient (log scale)")
fig.text(.09,.92,"Gradient flow in the original modified proxy",weight="bold",fontsize=18)
fig.text(.09,.86,"Same four 2,048-token sequences at both snapshots  ·  trial 000  ·  CPU, FP32",color="#36444e",fontsize=10.5)
handles,labels=axes[0].get_legend_handles_labels()
fig.legend(handles,labels,loc="lower center",ncol=3,frameon=False,fontsize=8.8,bbox_to_anchor=(.5,.018))
fig.savefig(folder/"gradient_by_layer.png", dpi=160,facecolor="white")
