import csv
import math
import torch
import trace_original as probe
from base_model_research.parameterization import build_model, make_optimizer
from base_model_research.training import CosineSchedule, seed_everything
from base_model_research.models import parameter_count

seed_everything(probe.settings.seed)
model = build_model(probe.config, probe.hp)
opt = make_optimizer(model,probe.settings)
sched = CosineSchedule(opt, math.ceil(parameter_count(model)*probe.settings.tokens_per_parameter/probe.production_batch),
                       probe.settings.warmup_fraction,probe.settings.min_lr_ratio)
for step in range(2):
    opt.zero_grad(set_to_none=True)
    sched.apply(step)
    x,y=probe.corpus.batch(step*probe.production_batch,probe.length,probe.length)
    loss = model.loss_sum(x,y,probe.settings.loss_chunk_size)/probe.length
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(),probe.settings.grad_clip)
    opt.step()
with (probe.destination/"fixed_inputs.tsv").open("w") as fh:
    probe.out=fh
    probe.writer=csv.writer(fh,delimiter="\t")
    probe.writer.writerow(["run","update","token_offset","layer","module","metric","value"])
    for offset in range(0,4*probe.length,probe.length):
        print("after two updates, fixed data",offset,probe.evaluate(model,"original_after_two",3,offset),flush=True)
def restore_identity(module, args, output):
    return args[0] + output
for l in model.layers:
    l.attention_gate.register_forward_hook(restore_identity)
    l.ffn_gate.register_forward_hook(restore_identity)
with (probe.destination/"fixed_inputs.tsv").open("a") as fh:
    probe.out = fh
    probe.writer = csv.writer(fh, delimiter="\t")
    for offset in range(0,4*probe.length,probe.length):
        print("after two updates, same weights with direct residuals",offset,probe.evaluate(model,"original_after_two_plus_identity",3,offset),flush=True)
