import csv
import json
import math
from collections import defaultdict
from dataclasses import replace
from pathlib import Path
from time import monotonic

import torch
from base_model_research.config import Hyperparameters, ModelConfig, TrainConfig
from base_model_research.data import TokenCorpus
from base_model_research.models import parameter_count
from base_model_research.parameterization import build_model, make_optimizer
from base_model_research.training import CosineSchedule, seed_everything

destination = Path(__file__).parent
torch.set_num_threads(3)
settings = TrainConfig.load("configs/training.yaml")
config = ModelConfig.load("configs/models/modified_proxy.yaml")
hp = Hyperparameters(**json.loads(Path("experiments/trials_seed42.json").read_text())["trials"][0]["hyperparameters"])
corpus = TokenCorpus(Path.home() / "Downloads/fineweb_edu_tinyllama", "train")
length = settings.context_length
production_batch = length * settings.global_batch_size

def rms(t):
    return t.detach().norm(dtype=torch.float64).item() / math.sqrt(t.numel())

def record(handle_key, tensor, data):
    data[handle_key, "value"] = rms(tensor)
    def save(grad):
        data[handle_key, "grad"] = rms(grad)
    tensor.register_hook(save)

def instrument(model, data):
    handles = []
    for i, layer in enumerate(model.layers, start=1):
        def input_hook(mod, args, i=i):
            record((i, "layer_input"), args[0], data)
        handles.append(layer.register_forward_pre_hook(input_hook))
        for name, module in layer.named_modules():
            if name in ("attention", "ffn", "attention_gate", "ffn_gate",
                        "attention_gate.current", "attention_gate.previous",
                        "ffn_gate.current", "ffn_gate.previous", "post_attention_norm"):
                def output_hook(mod, args, out, i=i, name=name):
                    record((i, name), out, data)
                handles.append(module.register_forward_hook(output_hook))
    return handles

def evaluate(model, run, index, offset, trace=True):
    model.zero_grad(set_to_none=True)
    acts = {}
    handles = instrument(model, acts) if trace else []
    ix, target = corpus.batch(offset, length, length)
    loss = model.loss_sum(ix, target, settings.loss_chunk_size) / length
    loss.backward()
    for h in handles:
        h.remove()
    total2 = 0.0
    for name, p in model.named_parameters():
        value = rms(p.grad)
        total2 += value**2 * p.numel()
        if trace:
            parts = name.split(".")
            layer, module = (int(parts[1])+1, ".".join(parts[2:-1])) if parts[0]=="layers" else (0, ".".join(parts[:-1]))
            writer.writerow([run,index,offset,layer,module,"weight_grad_rms",value])
    for ((layer, name), field), value in acts.items():
        writer.writerow([run,index,offset,layer,name,"output_rms" if field=="value" else "output_grad_rms",value])
    out.flush()
    return loss.item(), math.sqrt(total2)

if __name__ == "__main__":
    seed_everything(settings.seed)
    model = build_model(config, hp)
    standard = build_model(replace(config, family="standard"), hp)
    missing, extra = standard.load_state_dict(model.state_dict(), strict=False)
    assert not missing and all("_gate." in k for k in extra)
    optimizer = make_optimizer(model, settings)
    total_steps = math.ceil(parameter_count(model) * settings.tokens_per_parameter / production_batch)
    schedule = CosineSchedule(optimizer,total_steps,settings.warmup_fraction,settings.min_lr_ratio)
    start = monotonic()
    with (destination/"trace.tsv").open("w") as out:
        writer = csv.writer(out, delimiter="\t")
        writer.writerow(["run","update","token_offset","layer","module","metric","value"])
        for offset in (0, length, 2*length, 3*length):
            for label, m in (("original_init", model), ("identity_control_init", standard)):
                loss, norm = evaluate(m,label,0,offset)
                print(f"{label} offset {offset} loss {loss:.4g} grad norm {norm:.6g} ({monotonic()-start:.1f}s)", flush=True)
        del standard
        for step in range(1,21):
            schedule.apply(step-1)
            offset = (step-1)*production_batch
            loss,norm = evaluate(model, "original_small_batch", step, offset)
            clipped = torch.nn.utils.clip_grad_norm_(model.parameters(), settings.grad_clip).item()
            print(f"small batch update {step}: loss {loss:.4g}, norm (64-bit reduction) {norm:.6g} (training uses FP32: {clipped:.6g}); {monotonic()-start:.1f}s", flush=True)
            if not all(math.isfinite(x) for x in (loss, norm, clipped)):
                break
            optimizer.step()
